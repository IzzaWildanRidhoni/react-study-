import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
        {/* Gunakan tag <h1> untuk mendisplay "Hello World" */}
        <h1>Hello World</h1>
        <p>Ayo belajar React bersama-sama!</p>
        
        {/* Gunakan tag <p> untuk mendisplay "Ayo belajar React bersama-sama!" */}
        
        
      </div>
    );
  }
}

export default App;
